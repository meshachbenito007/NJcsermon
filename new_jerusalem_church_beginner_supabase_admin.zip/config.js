// Add your Supabase Project URL and Publishable/anon key here.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE";
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
